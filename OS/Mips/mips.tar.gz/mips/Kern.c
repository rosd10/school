#include <stdio.h>
#include "Def.h"
extern void *handlers[];

/* *******************************************************************
	Special interrupt handlers.

You have to define the central part of the interrupt handling here.
The central interrupt handler will be called by hardware and it will
save hardware state (registers), identify the interrupt, read some
info depending on type of interrupt and then call a user routine in
this module. After the return from this routine it will restore 
hardware and return to normal execution.
You have to init a special handler table, see the routine init below!
The routine are called with three parameters:
   int nr		- the interrupt code (0-external,...,8-syscall,....)
   unsigned long *hw	- address of register save area(xxx0,reg1, reg2,...,reg31,PC)
   int info		- info depending on interrupt
			  ext. puls: 1-right button, 2-left button, 4-periodic
				3,5,6,7 combinations!
			  other >=8 NOT USED in this project
The routines here has to take care of the interrupt, and SCHEDULE before
returning.
Schedule means that you have to decide on which process to restart after
the interrupt. This may be the same as the interrupted process, or some other
depending on the scheduling algorithm.
******************************************************************* */
int Clock;	// Used as a clock, updated by puls generator int.
int K;		// Used as a common variable for test purposes.
int nrOfPID;	//PID-counter
int queue[10];	//process-queue. Used for wait&signal

/* *******************************************************************
	Scheduling and Process Handling
Processes are created and started.
Scheduling is also implemented here.
******************************************************************* */


typedef struct
{  int ID;		// Process identity
   int State;		// Process state: running, ready, blocked
   int Prio;		// Priority
   int Rest;
   			// Plus what more thats needed .......
   unsigned long Hw[33];// hardware state
} PCB;



PCB Procs[10];		// existing processes (a list is better!)
int NextPID,CurPID;	// total number of processes, Running process.
int SysStart;		// 0 - first interrupt start proc, 1 - OS running.
unsigned long Mem[1024];// memory used for process stacks
/* **************************************************
	Handle process creation
A process has to be created, meaning that a
Process Control Block (PCB) has to be created,
a stack has to be allocated to the process and
some registers may have to be set for this process.
Register sp (number 29) points into stack
Register gp (number 28) used by c-code (here same for all procs.)
Register PC (number 32) is the address in the code for this proc.
Other registers. ????
Other process properties such as priority, state, ... must
of course be set in the PCB.
	Handle process start
Start is just setting the process state to Ready.
************************************************** */
static void Create(int Pri,unsigned long Adr,unsigned long gp)
{
    Procs[CurPID].ID = CurPID;
    Procs[CurPID].Prio = Pri;
    Procs[CurPID].State = Ready;
    Procs[CurPID].Rest = 0;
    Procs[CurPID].Hw[28] = gp;
    Procs[CurPID].Hw[29] = &Mem[(NextPID+1)*128];
    Procs[CurPID].Hw[32] = Adr;
}

static void Start(int PID) {
	Procs[PID].State = Ready;
	printf("Process %d set to ready.\n", Procs[PID].ID);
}

static void Wait() {
        if(Procs[CurPID].State == Ready || Procs[CurPID].State == Running) {
                Procs[CurPID].State = Blocked;
        }
        else {}
}

static void Signal() {
        if(Procs[CurPID].State == Blocked)
        {
                Procs[CurPID].State = Ready;
        }
}


/* ***************************************
   	The Null Process
When no other process is ready to run, this will be ready
but with lowest possible priority (=0). The state is always
ready or running, and of course never blocked.
The process doing nothing but loping waiting for
interrupts. If the loop is continued or the process
always will be restarted does not matter, as it's doing nothing.
**************************************** */
static void NullProc(){
    Display(0);
    while(1){}
}

static void Sleep(int PID, int sleepyTime) {
	Procs[PID].Rest = sleepyTime;
	Procs[PID].State = Blocked;
	printf("Process %d is sleeping...\n",PID);
}

/* *******************************************************************
   Interrupt handling
PulsGen   -   handling external interrupts
	      in this project always from PulsGen
SysHand   -   handle syscall interrupts
Default   -   other interrupts, should not occur, handled here
******************************************************************* */


static void PulsGen(int nr,unsigned long *hw,int info)
{
	printf("Dummy PulsGen Kod=%d\n",info);
	if(info==4){
		Clock++;
		int i;
		for (i = 1; i<nrOfPID; i++) {
			if (Procs[i].State == Blocked) {
				if (Procs[i].Rest > 0) {
					Procs[i].Rest -= 1;
					printf("Process %d is now: %d\n",i,Procs[i].Rest);
				}
				if (Procs[i].Rest == 0) {
					Procs[i].State = Ready;
					printf("Proc. %d is ready again.\n",i);
				}
			}
		}
		for (i=0; i<nrOfPID; i++) {
			printf("Proc %d state is %d.\n", i, Procs[i].State);
		}
	}
	else
	if(info==1) {
		printf("Right key\n");
		if(SysStart==0) {
      	/* Create processes here */
		Create(0,(unsigned long)NullProc,hw[28]); //NULL-proc
		printf("Nullproc created with pid: %d\n", Procs[0].ID);
		CurPID++;
		Create(19,(unsigned long)Program1,hw[28]); //First process in User.c;
		printf("Program1 created with pid: %d\n", Procs[1].ID);
		CurPID++;
		Create(15,(unsigned long)Program2,hw[28]); //Second process in User.c
		printf("Program2 created with pid: %d\n", Procs[2].ID);
		nrOfPID = 3;
		SysStart = 1;
		}
		else{}
	}
	else
	if(info=2){ //switch process
		Start(Procs[CurPID].ID);
	}

	Schedule(hw);

}

static void SysHand(int nr,unsigned long *hw,int info)
{  int Vilken;
   printf("SysHand syscall=%d\n",hw[2]);
   Vilken=hw[2];
   switch (Vilken)
   {
		case 1: //Sleep, add 'rest' to process
			Sleep(CurPID, (int)hw[4]);
		break;

		case 2:	//GetTime
		break;

		case 3:	//Create
			Create((Procs[CurPID].Prio+5),Procs[CurPID].Hw[32],hw[28]);
			printf("Created new process in pid: %d\n", CurPID);
		break;

		case 4:	//Wait
			Wait();
		break;

		case 5:	//Signal
			Signal();
		break;
   }

   Schedule(hw);
}

static void Default(int nr,unsigned long *hw,int info)
{  int I;
   printf("Exception nr:%d with info:%d\n",nr,info);
   printf("at PC=%x",hw[32]);

   Schedule(hw);
}
/* *******************************************************************
   Scheduling

Select will return the next process to run
   The ready process with highest priority or some other algorithm.
Save will save the hardware state in the current process PCB
Restore will load the hardware state from the new process PCB
******************************************************************* */

/* First test Select with no priority */
static int Select()
{
   if(SysStart==0)
	{
		K=0;
	} // null process pid=0
   else
   {
      K++;
      if(K==3)
	{
		K=1;
	}
   }
	printf("Scheduling returning %d\n",K);
	return K;
}
static void Save(unsigned long *H,int P)
{
	int i;
	for(i = 0; i<33; i++) {
		Procs[P].Hw[i] = H[i];
	}
}

static void Restore(unsigned long *H,int P)
{
	int i;
	for (i=0; i<33; i++) {
		H[i] = Procs[P].Hw[i];
	}
	CurPID = P;
	Procs[P].State = Ready;
}

static void Schedule(unsigned long *hw)
{   int Pind;
	Save(hw,CurPID);
	Pind=Select();
	Restore(hw, Pind);
	Procs[CurPID].State = Ready;
	Procs[Pind].State = Running;
	CurPID = Pind;
	printf("Switching to process %d\n", Pind);
}

/* *** SYSCALL ROUTINES *** */

/* *******************************************************************
   Semaphores
******************************************************************* */

/* *******************************************************************
	Init the table of interrupt handlers.
There are 16 different interrupts and set the routine for each as the Default
routine. Then change those you should define yourself. The external
interrupt (puls generator) should always be set. It is possible to test
this before you implement the system calls. This routine is called by
the OS setup code.
******************************************************************* */
int init() {
	int i;
	Clock=0; SysStart=0; K=0;
	Display(0);
	for(i=0;i<16;i=i+1){handlers[i]=Default;} // Set all handlers to Default
	handlers[0]=PulsGen;  // Set external puls generator interrupt handler
	handlers[8]=SysHand;  // Set syscall handler when you have defined syscalls

	printf("Start of KOS operating system\n");

	NextPID=0;
	CurPID=0;
}
