#include <stdio.h>
#include "Def.h"
/* *************************************************************
	User programs

************************************************************* */
static int S;
void Program1()
{  int cc;
   printf("Program 1");
   while(1){
		Display(1);
      	cc=2200;
      	while(cc>0){
			cc=cc-1;
			if (cc%2 == 0) {
				printf("cc = %d\n", cc);
			}
		}
	printf("Program 1 done. cc==%d\n", cc);
    Sys(1,6);	//calls for syscall 1 == wait. 6 equals the time the process will wait
	cc=1500;
    S=Sys(3);
    //Sys(4,S);
    //Display(8+1);
    Sys(1,8);
    //Display(8+1);
    //Sys(5,S);
    while(cc>0){cc=cc-1;}
   }
}
void Program2(){
	int W,cc;
	printf("Program 2");
	while(1) {
		Display(2);
		cc=10000;
		printf("cc2== %d\n",cc);
    		while(cc>0)
		{
			cc--;
			printf("cc2 == %d\n", cc);
		}
      //Sys(1,10);
      //Sys(4,S);
      //Display(8+2);
      //Sys(1,4);
      //Display(16+2);
      //Sys(5,S);
      //W=Sys(2);
      //Display(W);
	}
}
void Program3()
{  int cc,W;
   printf("Program 3");
   while(1)
   {  Display(3);
      cc=10000000;
      while(cc>0){cc=cc-1;}

      //W=Sys(2);
      //Display(W);
   }
}
void Program4()
{  int cc;
   printf("Program 4");
   while(1)
   {  Display(4);
      cc=1000000;
      while(cc>0){cc=cc-1;}
      //Sys(1,5);
   }
}
