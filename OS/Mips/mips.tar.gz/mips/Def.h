void Program1();
void Program2();
void Program3();
void Program4();
static void Schedule(unsigned long*);
extern int Sys(int,...);
extern void Display(int);
extern int Read();
extern void Halt(int);
#define Running	1
#define	Ready   2
#define	Blocked 3
